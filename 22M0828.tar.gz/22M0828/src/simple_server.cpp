// valgrind --tool=memcheck --leak-check=yes --show-leak-kinds=all --show-reachable=yes --num-callers=20 --track-origins=yes --trace-children=yes ./server 8000 5
// usage: ./server <port> <workers>

#include "http_server.hh"
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <assert.h>
#include <iostream>
#include <stdio.h>
#include <netdb.h>
#include <errno.h>
#include <queue>

pthread_cond_t clients_available = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
std::queue<int> buffer;
bool running = true;
int portno;

void error(char *msg) 
{
  perror(msg);
  exit(1);
}

void trap(int sigm)
{
  running = false;
  struct sockaddr_in serv_addr;
  int sockfd = socket(AF_INET, SOCK_STREAM, 0);
  struct hostent *server = gethostbyname("localhost");
  bzero((char *)&serv_addr, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(portno);
  bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr,server->h_length);
  connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
}

void *start_talking(void *arg) 
{
  while (running)
  {
    pthread_mutex_lock(&mutex);

    while(buffer.size() == 0 && running)
      pthread_cond_wait(&clients_available, &mutex);

    if (!running)
    {
      pthread_mutex_unlock(&mutex);
      break;
    }

    int newsockfd = buffer.front();
    buffer.pop();
    pthread_mutex_unlock(&mutex);

    char msg[256];
    int n;

    bzero(msg, 256);
    n = read(newsockfd, msg, 255);
    if (n < 0)
      perror("ERROR reading from socket");
    else
    {
      HTTP_Response *response = handle_request(msg);
      std::string res_send = response->get_string();
      int len_str = res_send.length() + 1;
      char char_array[len_str];
      strcpy(char_array, res_send.c_str());

      n = write(newsockfd, char_array, len_str);
      if (n < 0)
        perror("ERROR writing to socket");

      delete response;
    }
    close(newsockfd);
  }
  return 0;
}

int main(int argc, char *argv[]) 
{
  signal(SIGINT, &trap);

  int sockfd, num_workers;
  struct sockaddr_in serv_addr;
  
  if (argc < 3)
  {
    portno = 8000;
    num_workers = 5;
  }
  else
  {
    portno = atoi(argv[1]);
    num_workers = atoi(argv[2]);
  }

  // printf("Server:\n");
  // printf("Hostname: localhost\n");
  // printf("Port: %d\n", portno);
  // printf("Worker Count: %d\n", num_workers);

  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0)
    error("ERROR opening socket");

  bzero((char *)&serv_addr, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = INADDR_ANY;
  serv_addr.sin_port = htons(portno);

  if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    error("ERROR on binding");

  pthread_t *worker_threads = (pthread_t *)malloc(num_workers * sizeof(pthread_t));

  for(int i=0; i<num_workers; ++i)
    pthread_create(worker_threads+i, NULL, start_talking, NULL);

  struct sockaddr_in cli_addr;
  socklen_t clilen = sizeof(cli_addr);

  while (running)
  {
    listen(sockfd, 256);
    int newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);

    if (!running)
    {
      for(int i=0; i<num_workers; ++i)
        pthread_cond_signal(&clients_available);
      break;
    }
    
    if (newsockfd < 0)
      perror("ERROR on accept");
    else
    {
      pthread_mutex_lock(&mutex);
      buffer.push(newsockfd);
      pthread_mutex_unlock(&mutex);
      pthread_cond_signal(&clients_available);
    }
  }

  for(int i=0; i<num_workers; ++i)
    pthread_join(worker_threads[i], NULL);

  free(worker_threads);
  shutdown(sockfd,SHUT_RDWR);
  close(sockfd);
  return 0;
}