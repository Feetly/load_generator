#include "http_server.hh"
#include <sys/stat.h>
#include <time.h>
#include <fstream>
#include <sstream>
#include <vector>

std::vector<std::string> split(const std::string &s, char delim) 
{
  std::vector<std::string> elems;
  std::stringstream ss(s);
  std::string item;

  while (getline(ss, item, delim)) 
  {
    if (!item.empty())
      elems.push_back(item);
  }

  return elems;
}

HTTP_Request::HTTP_Request(std::string request) 
{
  std::vector<std::string> lines = split(request, '\n');
  if (lines.size())
  {
    std::vector<std::string> first_line = split(lines[0], ' ');
    this->method = first_line[0];
    this->url = first_line[1];
  }
  else
  {
    this->method = "Empty";
    this->url = "";
  }
  
  this->HTTP_version = "1.0"; // We'll be using 1.0 irrespective of the request

  // if (this->method != "GET")
  //   std::cerr << "Method '" << this->method << "' not supported" << std::endl;
}

HTTP_Response *handle_request(std::string req) 
{
  HTTP_Request *request = new HTTP_Request(req);
  HTTP_Response *response = new HTTP_Response();
  std::string url = std::string("html_files") + request->url;
  response->HTTP_version = "1.0";

  struct stat sb;
  if ((stat(url.c_str(), &sb) == 0) && ( request->method == "GET" )) // requested path exists
  {
    response->status_code = "200";
    response->status_text = "OK";
    response->content_type = "text/html";

    if (S_ISDIR(sb.st_mode)) 
      url += std::string("/index.html");

    std::ifstream myfile; 
    myfile.open(url);
    
    response->body = "";
    if ( myfile.is_open() ) 
    {
      while ( myfile ) 
        response->body += myfile.get();
    }

    response->content_length = std::to_string(response->body.length());
  } 
  else 
  {
    response->status_code = "404";

    response->status_text = "Not Found";
    response->content_type = "text/html";
    response->body = "<html>404 File Not Found</html>\r\n";
    response->content_length = std::to_string(response->body.length());
  }

  delete request;
  return response;
}

std::string HTTP_Response::get_string() 
{
  std::string res_str = "";
  res_str += "HTTP/" + this->HTTP_version + " " + this->status_code + " " +  this->status_text + "\r\n";
  res_str += "Content-Type: " + this->content_type + "\r\n" + "Content-Length: " + this->content_length + "\r\n";
  res_str += "\r\n";
  res_str += this->body;

  return res_str;
}