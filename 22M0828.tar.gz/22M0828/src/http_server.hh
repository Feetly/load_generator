#ifndef _HTTP_SERVER_HH_
#define _HTTP_SERVER_HH_

#include <iostream>

struct HTTP_Request 
{
  HTTP_Request(std::string request); // Constructor

  std::string HTTP_version;
  std::string method;
  std::string url;
};

struct HTTP_Response 
{
  std::string HTTP_version;
  std::string status_code;
  std::string status_text;
  std::string content_type;
  std::string content_length;
  std::string body;

  std::string get_string(); // Returns the string representation of the HTTP Response
};

HTTP_Response *handle_request(std::string request);

#endif
